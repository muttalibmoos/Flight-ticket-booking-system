-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 02, 2021 at 02:13 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `AirLineReservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookedFlights`
--

CREATE TABLE `bookedFlights` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `Destination` varchar(255) NOT NULL,
  `SeatsChosen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookedFlights`
--

INSERT INTO `bookedFlights` (`id`, `name`, `Destination`, `SeatsChosen`) VALUES
(1, 'muttalib ', 'Bora Bora', 2),
(3, 'fatima ', 'Dubai, ', 258),
(4, 'cameron', 'Dubai, ', 5);

-- --------------------------------------------------------

--
-- Table structure for table `Flight of the Database`
--

CREATE TABLE `Flight of the Database` (
  `ID` int(10) NOT NULL,
  `Destination` varchar(255) NOT NULL,
  `Departure` datetime NOT NULL,
  `Duration` time NOT NULL,
  `Arrival` datetime NOT NULL,
  `AvailableSeats` int(2) NOT NULL,
  `Price` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Flight of the Database`
--

INSERT INTO `Flight of the Database` (`ID`, `Destination`, `Departure`, `Duration`, `Arrival`, `AvailableSeats`, `Price`) VALUES
(1, 'South Island New Zealand', '2021-07-13 13:00:00', '20:35:00', '2021-07-14 09:35:00', 10, 'R 28 332.00'),
(2, 'Paris ', '2021-07-13 15:00:00', '10:50:00', '2021-07-14 01:50:00', 8, 'R 13 101.00'),
(3, 'Bora bora ', '2021-07-13 17:00:00', '10:15:00', '2021-07-14 12:15:00', 32, 'R 159 789.00'),
(7, 'Maui', '2021-07-13 19:00:00', '27:41:00', '2021-07-14 22:41:00', 18, 'R 34 789.00'),
(8, 'Tahiti', '2021-07-13 21:00:00', '47:46:00', '2021-07-15 20:46:00', 33, 'R 140 010.00'),
(9, 'London', '2021-07-13 23:00:00', '12:05:00', '2021-07-14 11:05:00', 4, 'R 14 931'),
(10, 'Rome', '2021-07-13 01:00:00', '13:55:00', '2021-07-13 14:55:00', 2, 'R 11 170'),
(11, 'Tokyo', '2021-07-13 03:00:00', '22:05:00', '2021-07-14 01:05:00', 10, 'R 22 508.00'),
(12, 'Barcelona', '2021-07-13 05:00:00', '14:05:00', '2021-07-13 19:05:00', 27, 'R 12 903.00'),
(13, 'Maldives', '2021-07-13 07:00:00', '16:15:00', '2021-07-13 23:15:00', 6, 'R 21 848.00'),
(14, 'New York ', '2021-07-13 08:00:00', '19:40:00', '2021-07-14 03:40:00', 11, 'R 24 463'),
(15, 'Bali ', '2021-07-13 06:00:00', '03:00:00', '2021-07-14 09:00:00', 2, 'R 19 555.00'),
(16, 'Sydney Australia', '2021-07-13 04:00:00', '22:15:00', '2021-07-14 02:15:00', 22, 'R 25 864.00'),
(17, 'Dubai', '2021-07-13 02:00:00', '09:30:00', '2021-07-13 11:30:00', 23, 'R 16 838.00'),
(18, 'Cancun', '2021-07-13 00:00:00', '02:00:00', '2021-07-14 02:00:00', 24, 'R 28 783.00'),
(19, 'Los Angeles', '2021-07-13 22:00:00', '26:00:00', '2021-07-15 00:00:00', 30, 'R 25 344.00'),
(20, 'Moscow', '2021-07-13 20:00:00', '15:15:00', '2021-07-14 11:15:00', 37, 'R 14 354.00'),
(21, 'Singapore', '2021-07-13 18:00:00', '13:30:00', '2021-07-14 07:30:00', 35, 'R 16 132.00'),
(22, 'Hong Kong', '2021-07-13 16:00:00', '19:45:00', '2021-07-14 11:45:00', 12, 'R 15 005.00'),
(23, 'Rio de Janeiro', '2021-07-13 14:00:00', '20:50:00', '2021-07-14 10:50:00', 9, 'R 27 778.00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age` int(255) NOT NULL,
  `phone` int(10) NOT NULL,
  `money` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `name`, `username`, `password`, `age`, `phone`, `money`) VALUES
(2, 'muttalib moos', 'mr.m', 'open1', 22, 748109930, 0),
(3, 'iman moos', 'babymoos', 'open2', 20, 217065453, 0),
(4, 'fatima moos', 'mimi', 'open3', 17, 761237654, 0),
(5, 'juneid moos', 'shorty', 'open4', 50, 765929070, 0),
(6, 'seb vettel', 'vettel', 'open5', 34, 34, 0),
(7, 'qadira moos', 'qmoos', 'open7', 10, 987654321, 0),
(8, 'cameron', 'okayokay', 'open9', 22, 1234567, 0),
(9, 'cameron', 'okaynow', 'open10', 22, 987657, 0),
(10, 'saajid', 'parker', 'open11', 22, 12346654, 0),
(11, 'saajid', 'parker1', 'open12', 22, 123456543, 999);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookedFlights`
--
ALTER TABLE `bookedFlights`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Flight of the Database`
--
ALTER TABLE `Flight of the Database`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookedFlights`
--
ALTER TABLE `bookedFlights`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Flight of the Database`
--
ALTER TABLE `Flight of the Database`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
