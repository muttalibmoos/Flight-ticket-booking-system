package Question2Payment;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.jdbc.Connection;

public class Payment 
{
	Scanner input = new Scanner(System.in);	

	
	public String promptUser()
	{		
		Connection connection = null;
		
		try {			
			String driverName = "com.mysql.jdbc.Driver";
			Class.forName(driverName);			
			String serverName = "192.168.18.2";
			String schema = "AirLineReservation";
			String url = "jdbc:mysql://" +serverName + "/" + schema;
			
			String username = "moos";
			String password = "1234";			
			connection = (Connection) DriverManager.getConnection(url, username, password);
			
		}catch(Exception e) {
			System.out.println("Error while trying to connect to Database");
		}
		
		System.out.println("Welcome! could you please enter your unique user id");
		int id = input.nextInt();
		
		try {
			
			Statement statement = connection.createStatement();
			
			String sql = ("SELECT `uid`,`name`,`password`,`money` FROM `users` WHERE `uid` = " + id + ";");
			
			ResultSet results = statement.executeQuery(sql);
			
			while(results.next()) {
				
			id = results.getInt("uid");
			String name = results.getString("name");
			String money = results.getString("money");
				
				System.out.println("Hello "+ name+ " You currently have R " + money + " to pay on your account");
			}
		}
		catch(Exception e) {
			
			System.out.println("Error while trying to get data for user id "+ id);
			System.out.println(e);
			
		}
		
	try {
		
		
		Statement stmt = connection.createStatement();
		System.out.println("How much would you like to pay off on your account?");	
		int paymentAmount = input.nextInt();	
		
		
		String sql = ("SELECT `uid`,`name`,`password`,`money` FROM `users` WHERE `uid` = " + id + ";");	
		
		ResultSet result = stmt.executeQuery(sql);
		
		int money = 0;
		int total =0;
		while(result.next()) 
			{
			
					int ids = result.getInt("uid");
					String first_name = result.getString("name");
					money = result.getInt("money");
						
					
					total = money - paymentAmount;					
					System.out.println("Thank you for making an instalment, You still owe " + total + " on your account");			
			}			
		
				
	
	
		}
			catch(Exception e){
		
			
			
		}
		

		return null;	
	}
	
	
	
	
}
