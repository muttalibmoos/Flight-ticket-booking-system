package Question2Receipt;

import java.io.FileOutputStream;
import java.io.PrintStream;

public class Receipt {

	public String MyReceipt() {
		
		
		
		return "This is your Receipt for the payment made to your flights account ";
		
		
		
		
		
		
	}
	
}
