module Question2Receipt {
	exports Question2Receipt;
}