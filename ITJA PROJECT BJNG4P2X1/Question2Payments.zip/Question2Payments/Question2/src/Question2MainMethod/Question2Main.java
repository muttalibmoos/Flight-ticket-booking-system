package Question2MainMethod;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintStream;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.DriverManager;
import com.mysql.jdbc.Connection;
import Question2Payment.Payment;
import Question2Receipt.Receipt;



public class Question2Main {


	


	public static void main(String arg[]) throws FileNotFoundException {	
		Scanner input = new Scanner(System.in);						
		Payment pay = new Payment();
		Receipt receipt = new Receipt();
		
		pay.promptUser();
		
		
		
		//String answer = null;
		
		//System.out.println("Would you like a Receipt? (y/n)");
		
		//String answer = input.next();
		
		
		//if(answer == "y")
		//{
			try 
			{
				FileWriter printReceipt = new FileWriter("yourReceipt.txt");
				//printReceipt.write(receipt.MyReceipt());
				
				PrintStream out = new PrintStream(
						new FileOutputStream("yourReceipt.txt", true), true);
				
				System.setOut(out);
				
				printReceipt.close();
				
				System.out.println("your receipt has been printed");
				
			}
			catch(Exception e){
				
				System.out.println(e);
				
			}
			
			try 
			{
				
				
				//System.setOut(out);
				
				/*File file = new File("yourReceipt.txt");
				
				
				
				if(file.createNewFile())
				{
					System.out.println("file created");
				}*/
			}
			catch(Exception ex)
			{
				System.out.println(ex);
			}
		//}
		
			
	}

	



	
	
	
}
