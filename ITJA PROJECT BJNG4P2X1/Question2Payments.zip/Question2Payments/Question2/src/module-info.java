module Question2Payment {
	exports Question2MainMethod;
	requires Question2;
	requires Question2Receipt;
	requires mysql.connector.java;
	requires java.sql;


}