package com.example.airline_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class delete extends AppCompatActivity {

    EditText name;
    MultiAutoCompleteTextView destination;
    EditText SeatsChosen;
    Button delete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        name = findViewById(R.id.name);
        destination = findViewById(R.id.destination);
        SeatsChosen = findViewById(R.id.SeatsChosen);
        delete = findViewById(R.id.delete);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, COUNTRIES);
        MultiAutoCompleteTextView okay = findViewById(R.id.destination);
        okay.setAdapter(adapter);
        okay.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new dbService().execute();
            }
        });
    }
    class dbService extends AsyncTask<Void, Void, Void>
    {
        Connection conn;

        @Override
        protected Void doInBackground(Void... voids)
        {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                conn = DriverManager.getConnection("jdbc:mysql://192.168.18.2:3306/AirLineReservation", "moos", "1234");
                System.out.println("Connection" + conn);

                String query = "DELETE from bookedFlights WHERE (name, Destination, SeatsChosen) VALUES ( ?, ?, ?);";
                PreparedStatement preparedStatement = conn.prepareStatement(query);
                preparedStatement.setString(1, name.getText().toString());
                preparedStatement.setString(2, destination.getText().toString());
                preparedStatement.setInt(3, Integer.parseInt(SeatsChosen.getText().toString()));
                // preparedStatement.setInt(4, Integer.parseInt(Price.getText().toString()));
                preparedStatement.executeUpdate();

            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private static final String[] COUNTRIES = new String[] {
            "South Island, New Zealand",
            "Paris",
            "Bora Bora",
            "Muai",
            "Tahiti",
            "London",
            "Rome",
            "Tokyo",
            "Barcelona",
            "Maldives",
            "New York",
            "Bali",
            "Sydney, Australia",
            "Dubai",
            "Mexico",
            "Havana, Cuba",
            "Los Angeles",
            "Moscow, Russia",
            "Singapore",
            "Hong Kong"
    };


}