package com.example.airline_management_system;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.airline_management_system.dao.UserDao;
import com.example.airline_management_system.entity.User;

public class registration extends AppCompatActivity {

    EditText name = null;
    EditText username = null;
    EditText email = null;
    EditText phone = null;
    EditText age = null;
    EditText password = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name = findViewById(R.id.name);
        username = findViewById(R.id.username);
        phone = findViewById(R.id.phone);
        age = findViewById(R.id.age);
        password = findViewById(R.id.password);
    }

    public void register(View view){

        String cname = name.getText().toString();

        String cusername = username.getText().toString();

        String cpassword = password.getText().toString();

        int cgae = Integer.parseInt(age.getText().toString());

        System.out.println(phone.getText().toString());
        String cphone = phone.getText().toString();


        if(cname.length() < 2 || cusername.length() < 2 || cpassword.length() < 2 ){
            Toast.makeText(getApplicationContext(), "the input information does not meet the requirements, please re-enter", Toast.LENGTH_LONG).show();
            return;

        }


        User user = new User();

        user.setName(cname);
        user.setUsername(cusername);
        user.setPassword(cpassword);
        user.setAge(cgae);
        user.setPhone(cphone);

        new Thread(){
            @Override
            public void run() {

                int msg = 0;

                UserDao userDao = new UserDao();

                User uu = userDao.findUser(user.getName());

                if(uu != null){
                    msg = 1;
                }

                boolean flag = userDao.register(user);
                if(flag){
                    msg = 2;
                }
                hand.sendEmptyMessage(msg);

            }
        }.start();


    }
    final Handler hand = new Handler()
    {
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 0)
            {
                Toast.makeText(getApplicationContext(), "registration failed", Toast.LENGTH_LONG).show();

            }
            if(msg.what == 1)
            {
                Toast.makeText(getApplicationContext(), "this account already exists, please change another account", Toast.LENGTH_LONG).show();

            }
            if(msg.what == 2)
            {
                //startActivity(new Intent(getApplication(),MainActivity.class));

                Intent intent = new Intent();
                //Encapsulate the data you want to transfer in intent with putextra
                intent.putExtra ("a", "registration");
                setResult(RESULT_CANCELED,intent);
                finish();
            }

        }
    };
}