package com.example.airline_management_system;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyAppAdapter extends RecyclerView.Adapter<MyAppAdapter.ViewHolder> {
    private List<ClassListItems> values;
    public Context context;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textName;
        public ImageView imageView;
        public View layout;

        public ViewHolder(View v) {
            super(v);
            layout = v;
            textName = (TextView) v.findViewById(R.id.details);
            imageView = (ImageView) v.findViewById(R.id.image);
        }

    }

    public MyAppAdapter(List<ClassListItems> myDataset, Context context) {
        values = myDataset;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.list_content, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return values.size();
    }


}
