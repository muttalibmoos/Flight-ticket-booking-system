package com.example.airline_management_system;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class home extends AppCompatActivity {

    private ArrayList<ClassListItems> itemsArrayList;
    private MyAppAdapter myAppAdapter;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private boolean success = false;



    //private static final String DB_URL = "jdbc:mysql://192.168.18.2:3306/AirLineReservation";
  //  private static final String DB_USER = "moos";
   // private static final String PASSWORD = "1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLayoutManager);




        itemsArrayList = new ArrayList<ClassListItems>();
                SyncData orderData = new SyncData();
                orderData.execute("");

    }


    public void newbooking(View view){

        startActivity(new Intent(getApplicationContext(),newBooking.class));

    }


    public void booked(View view){

        startActivity(new Intent(getApplicationContext(),bookedFlights.class));

    }

    private class SyncData extends AsyncTask<String, String, String>
    {
        ProgressDialog progress;

        @Override
        protected void onPreExecute()
        {
             progress = ProgressDialog.show(home.this, "synchronising", "the flights are laoding please wait", true);
        }

        @Override
        protected String doInBackground(String... strings)
        {
            String msg = "okay";
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.18.2:3306/AirLineReservation","moos","1234");
                if(conn == null)
                {
                    success = false;
                }
                else
                {
                    String query = "SELECT  Destination, Duration, AvailableSeats, Price from Flight of the Database";
                    ResultSet rs;
                    try (Statement stmt = conn.createStatement()) {
                        rs = stmt.executeQuery(query);
                    }
                    if(rs == null)
                    {
                        while (rs.next())
                        {
                            try
                            {
                             itemsArrayList.add(new ClassListItems(rs.getString("Destination"), rs.getString("Duration"), rs.getString("AvailableSeats"), rs.getString("Price")));
                            }
                            catch (Exception ex)
                            {
                                ex.printStackTrace();
                            }
                            msg = "found";
                            success = true;
                        }
                    }else
                    {
                        msg = "no flights found";
                        success = false;
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                Writer writer = new StringWriter();
                e.printStackTrace(new PrintWriter(writer));
                msg = writer.toString();
                success = false;

            }
            return msg;
        }

        @Override
        protected void onPostExecute(String msg)
        {
            progress.dismiss();
            Toast.makeText(home.this, msg + "", Toast.LENGTH_LONG).show();
            if(success == false)
            {
            }
            else
            {
                try{
                    myAppAdapter = new MyAppAdapter(itemsArrayList, home.this);
                    recyclerView.setAdapter(myAppAdapter);
                }
                catch(Exception ex)
                {

                }
            }
        }
    }
}

