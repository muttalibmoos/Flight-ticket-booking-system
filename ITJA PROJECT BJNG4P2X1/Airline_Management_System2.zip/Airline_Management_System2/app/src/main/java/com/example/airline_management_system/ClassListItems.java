package com.example.airline_management_system;

class ClassListItems
{
    public String img;
    public String name;

    public ClassListItems(String destination, String duration, String img, String name)
    {
        this.img = img;
        this.name = name;
    }

    public ClassListItems(String name, String destination, String seatsChosen) {
    }

    public String getImg()
    {
        return img;
    }

    public String getName()
    {
        return name;
    }
}
