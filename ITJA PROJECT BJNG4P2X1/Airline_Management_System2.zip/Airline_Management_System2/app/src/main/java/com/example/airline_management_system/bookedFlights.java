package com.example.airline_management_system;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



public class bookedFlights extends AppCompatActivity {

    Button cancel;

    private ArrayList<ClassListItems> itemsArrayList;
    private MyAppAdapter myAppAdapter;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private boolean success = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booked_flights);



        recyclerView = (RecyclerView) findViewById(R.id.recyclerView2);
        recyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLayoutManager);


        itemsArrayList = new ArrayList<ClassListItems>();
        bookedFlights.SyncData orderData = new bookedFlights.SyncData();
        orderData.execute("");


    }

    public void cancel(View view){

        startActivity(new Intent(getApplicationContext(),delete.class));

    }


    private class SyncData extends AsyncTask<String, String, String>
    {
        ProgressDialog progress;

        @Override
        protected void onPreExecute()
        {
            progress = ProgressDialog.show(bookedFlights.this, "synchronising", "the flights are laoding please wait", true);
        }

        @Override
        protected String doInBackground(String... strings)
        {
            String msg = "okay";
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.18.2:3306/AirLineReservation","moos","1234");
                if(conn == null)
                {
                    success = false;
                }
                else
                {
                    String query = "SELECT * from bookedFlights";
                    ResultSet rs;
                    try (Statement stmt = conn.createStatement()) {
                        rs = stmt.executeQuery(query);
                    }
                    if(rs == null)
                    {
                        while (rs.next())
                        {
                            try
                            {
                                itemsArrayList.add(new ClassListItems(rs.getString("name"), rs.getString("Destination"), rs.getString("SeatsChosen")));
                            }
                            catch (Exception ex)
                            {
                                ex.printStackTrace();
                            }
                            msg = "found";
                            success = true;
                        }
                    }else
                    {
                        msg = "no flights found";
                        success = false;
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
                Writer writer = new StringWriter();
                e.printStackTrace(new PrintWriter(writer));
                msg = writer.toString();
                success = false;

            }
            return msg;
        }

        @Override
        protected void onPostExecute(String msg)
        {
            progress.dismiss();
            Toast.makeText(bookedFlights.this, msg + "", Toast.LENGTH_LONG).show();
            if(success == false)
            {
            }
            else
            {
                try{
                    myAppAdapter = new MyAppAdapter(itemsArrayList, bookedFlights.this);
                    recyclerView.setAdapter(myAppAdapter);
                }
                catch(Exception ex)
                {

                }
            }
        }
    }

}